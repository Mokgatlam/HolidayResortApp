﻿using HolidayResortApp.Application.Common.Interfaces;
using HolidayResortApp.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HolidayResortApp.Infrastructure.Repository
{
    public class UnitOfWork : IUnitofWork
    {
        private readonly ApplicationDbContext _db;
        public IVillaRepository Villa{get; private set;}
        public IVillaNumberRepository VillaNumber{get; private set;}
       


        public UnitOfWork(ApplicationDbContext db)
        {
            _db = db;
            Villa = new VillaRepository(_db);
            VillaNumber = new VillaNumberRepository(_db);
        
        }

        public void Save()
        {
            _db.SaveChanges();
        }
    }
}
