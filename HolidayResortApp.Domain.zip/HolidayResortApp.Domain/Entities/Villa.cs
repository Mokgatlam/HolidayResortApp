﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HolidayResortApp.Domain.Entities
{
    public class Villa
    {
        public int Id { get; set; }
        [Display(Name = "Name")]
        [MaxLength(50)]
        public required string Name { get; set; }
        [Display(Name = "Description")]
        public string? Description { get; set; }
        [Display(Name = "Price per night")]
        [Range(100,10000)]
        public double Price { get; set; }
        [Display(Name = "Squarefoot size")]
        public int Sqft { get; set; }
        [Display(Name = "Occupancy")]
        [Range(1,10)]

        public int Occupancy { get; set; }
        [Display(Name="Image URL")]
        public string? ImgUrl { get; set; }
        public DateTime? Created_Date { get; set; }
        public DateTime? Updated_Date { get; set; }
    }
}
